
// Simple shop script: loads products.json, manages cart in localStorage, allows basic checkout export
async function loadProducts() {
  const res = await fetch('assets/products.json');
  const products = await res.json();
  const grid = document.getElementById('product-grid');
  products.forEach(p => {
    const card = document.createElement('div');
    card.className = 'bg-white rounded-lg shadow p-4 flex flex-col';
    card.innerHTML = `
      <img src="${p.image}" alt="${p.name}" class="w-full h-48 object-cover rounded-md">
      <h4 class="mt-3 font-semibold">${p.name}</h4>
      <p class="text-sm text-slate-600 mt-1">${p.description}</p>
      <div class="mt-3">` + renderVariants(p) + `</div>
    `;
    grid.appendChild(card);
  });
}

function renderVariants(p) {
  let html = '<div class="mt-2 space-y-2">';
  p.variants.forEach((v, idx) => {
    html += `<div class="flex items-center justify-between border rounded p-2">
      <div>
        <div class="text-sm font-medium">${v.label}</div>
        <div class="text-xs text-slate-500">${v.info || ''}</div>
      </div>
      <div class="text-right">
        <div class="font-semibold">${v.price.toLocaleString()} FCFA</div>
        <button class="mt-2 px-3 py-1 rounded bg-amber-900 text-white" onclick="addToCart(${p.id}, ${idx})">Ajouter</button>
      </div>
    </div>`;
  });
  html += '</div>';
  return html;
}

let cart = JSON.parse(localStorage.getItem('bois_cart') || '[]');
function saveCart() { localStorage.setItem('bois_cart', JSON.stringify(cart)); renderCart(); }
function renderCart() {
  const list = document.getElementById('cart-list');
  list.innerHTML = '';
  let total = 0;
  cart.forEach((it, i) => {
    total += it.price;
    const li = document.createElement('li');
    li.className = 'flex justify-between items-center';
    li.innerHTML = `<div>${it.name} <span class="text-xs text-slate-500">(${it.variant})</span></div>
      <div class="flex items-center space-x-2"><div>${it.price.toLocaleString()} FCFA</div><button onclick="removeFromCart(${i})" class="px-2">✖</button></div>`;
    list.appendChild(li);
  });
  document.getElementById('cart-total').textContent = total.toLocaleString();
}

function addToCart(productId, variantIndex) {
  fetch('assets/products.json').then(r=>r.json()).then(products=>{
    const p = products.find(x=>x.id===productId);
    const v = p.variants[variantIndex];
    cart.push({ id: productId, name: p.name, variant: v.label, price: v.price });
    saveCart();
  });
}

function removeFromCart(i) { cart.splice(i,1); saveCart(); }

// Checkout modal handling
document.addEventListener('click', (e)=>{
  if(e.target && e.target.id==='checkout-btn') {
    document.getElementById('checkout-modal').classList.remove('hidden');
    document.getElementById('checkout-modal').classList.add('flex');
  }
  if(e.target && e.target.id==='close-checkout') {
    document.getElementById('checkout-modal').classList.add('hidden');
    document.getElementById('checkout-modal').classList.remove('flex');
  }
  if(e.target && e.target.id==='confirm-checkout') {
    handleCheckout();
  }
});

document.addEventListener('change', (e)=>{
  if(e.target && e.target.name==='pay') {
    const v = e.target.value;
    document.getElementById('momo-form').classList.toggle('hidden', v!=='momo');
  }
});

function handleCheckout() {
  const pay = document.querySelector('input[name="pay"]:checked').value;
  const total = cart.reduce((s,a)=>s+a.price,0);
  if(cart.length===0) { alert('Votre panier est vide'); return; }
  const order = { created: new Date().toISOString(), items: cart, total };

  if(pay==='momo') {
    const phone = document.getElementById('momo-phone').value.trim();
    if(!phone) { alert('Veuillez entrer votre numéro mobile'); return; }
    order.payment = { method: 'Mobile Money', phone };
    // Provide downloadable order and prefilled mailto so user can complete payment manually
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(order, null, 2));
    const a = document.createElement('a');
    a.href = dataStr;
    a.download = 'order_boisivoire.json';
    a.click();
    window.location.href = `mailto:contact@boisivoire.ci?subject=Commande%20BoisIvoire&body=Bonjour,%0A%0AJe%20vous%20envoie%20ma%20commande%20(voir%20fichier%20téléchargé).%0ATotal%20:${total.toLocaleString()}%20FCFA%0A%0AMerci.`;
    alert('Fichier de commande téléchargé et mail préparé. Suivez les instructions pour payer via Mobile Money.');
    cart = []; saveCart(); document.getElementById('checkout-modal').classList.add('hidden');
    return;
  }

  if(pay==='paypal') {
    // For PayPal, we can't process here; create order file and open PayPal page instructions
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(order, null, 2));
    const a = document.createElement('a');
    a.href = dataStr;
    a.download = 'order_boisivoire.json';
    a.click();
    window.open('https://www.paypal.com', '_blank');
    alert('Fichier de commande téléchargé. Ouvrez PayPal pour payer manuellement puis envoyez-nous le reçu.');
    cart = []; saveCart(); document.getElementById('checkout-modal').classList.add('hidden');
    return;
  }

  if(pay==='stripe') {
    // Stripe requires server keys — show guidance and export order
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(order, null, 2));
    const a = document.createElement('a');
    a.href = dataStr;
    a.download = 'order_boisivoire.json';
    a.click();
    alert('Stripe nécessite une configuration côté serveur. Un fichier de commande a été téléchargé pour finaliser la commande manuellement.');
    cart = []; saveCart(); document.getElementById('checkout-modal').classList.add('hidden');
    return;
  }
}

// Init
loadProducts();
renderCart();
